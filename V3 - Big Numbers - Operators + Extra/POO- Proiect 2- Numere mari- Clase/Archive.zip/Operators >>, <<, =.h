//
//  BigNumber operators.h
//  POO- Proiect 2- Numere mari- Clase
//
//  Created by Ioana Toma on 18/04/14.
//  Copyright (c) 2014 Ioana Toma. All rights reserved.
//

#include <iostream>
#include <fstream>

using namespace std;

istream& operator>> (istream& y, BigNumber &number) //citeste numarul mare de la tastatura, cifra cu cifra, incepand cu semnul, apoi cifra
{                                                   // unitatilor; citirea se opreste cand este introdus "-1"
    int x;
    y >> x;
    while (x != -1)
    {
        number.add_elem (x);
        y >> x;
    }
    return y;
}

ostream& operator<< (ostream& y, BigNumber &number)
{
    elem *p;
    p = number.end;
    if (number.start->info == 10) y << "+"; //afisez semnul numarului; 10 = '+', 11 = '-'
    else y << "-";
    while (p->prev) //conditia este pusa astfel deoarece primul nod reprezinta semnul, pe care l-am afisat deja,deci merge pana la al doilea nod
    {
        y << p->info;
        p = p->prev;
    }
    return y;
}

BigNumber BigNumber::operator= (BigNumber x) //supraincarcarea operatorului =; creeaza un nou numar mare in care va pune, element cu element,
{                                            //informatia din fiecare nod din numarul pe care il copiaza
    delete_number();
    elem *x1;
    x1 = x.start;
    while (x1)
    {
        add_elem(x1->info);
        x1 = x1->next;
    }
    return *this;
}
